package br.com.fiap.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_SISTEMA")
@SequenceGenerator(name = "sistema", sequenceName = "SQ_TAB_SISTEMA", allocationSize = 1)
public class Sistema {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sistema")
	@Column(name = "cod_sistema")
	private Integer codigoSistema;

	@Column(name = "nom_sistema")
	private String nomeSistema;

	@OneToMany(mappedBy = "sistema")
	private List<CasoTeste> listaCasoTeste;

	public Integer getCodigoSistema() {
		return codigoSistema;
	}

	public void setCodigoSistema(Integer codigoSistema) {
		this.codigoSistema = codigoSistema;
	}

	public String getNomeSistema() {
		return nomeSistema;
	}

	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}

	public List<CasoTeste> getListaCasoTeste() {
		return listaCasoTeste;
	}

	public void setListaCasoTeste(List<CasoTeste> listaCasoTeste) {
		this.listaCasoTeste = listaCasoTeste;
	}

}
