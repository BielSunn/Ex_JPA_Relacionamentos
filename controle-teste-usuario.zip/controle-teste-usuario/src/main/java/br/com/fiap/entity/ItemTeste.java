package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_ITEM_TESTE")
@SequenceGenerator(name = "item_teste", sequenceName = "SQ_TAB_ITEM_TESTE", allocationSize = 1)
public class ItemTeste {

	@Id
	@GeneratedValue(generator = "item_teste", strategy = GenerationType.SEQUENCE)
	@Column(name = "cod_item_teste")
	private Integer codItemTeste;

	@Column(name = "cod_caso_teste")
	private Integer codCasoTeste;
	
	// Referencia a classe com FK
	@OneToOne
	@JoinColumn
	private CasoTeste casoTeste;

	public Integer getCodItemTeste() {
		return codItemTeste;
	}

	public void setCodItemTeste(Integer codItemTeste) {
		this.codItemTeste = codItemTeste;
	}

	public Integer getCodCasoTeste() {
		return codCasoTeste;
	}

	public void setCodCasoTeste(Integer codCasoTeste) {
		this.codCasoTeste = codCasoTeste;
	}

}
