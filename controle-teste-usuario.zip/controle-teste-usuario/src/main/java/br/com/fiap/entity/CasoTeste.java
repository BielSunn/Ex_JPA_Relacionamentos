package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_CASO_TESTE")
@SequenceGenerator(name = "caso_teste", sequenceName = "SQ_TAB_CASO_TESTE", allocationSize = 1)
public class CasoTeste {

	@Id
	@GeneratedValue(generator = "caso_teste", strategy = GenerationType.SEQUENCE)
	@Column(name = "cod_caso_teste")
	private Integer codCasoTeste;

	@Column(name = "nom_caso_teste")
	private String nomeCasoTeste;

	@Column(name = "cod_sistema")
	private Integer codSistema;
	
	// Referenciando a classe da FK
	@ManyToOne
	@JoinColumn(name = "cod_sistema")
	private Sistema sistema;
	
	// Classe que nao tem a FK
	@OneToMany(mappedBy = "casoTeste")
	private ItemTeste itemTeste;

	public Integer getCodCasoTeste() {
		return codCasoTeste;
	}

	public void setCodCasoTeste(Integer codCasoTeste) {
		this.codCasoTeste = codCasoTeste;
	}

	public String getNomeCasoTeste() {
		return nomeCasoTeste;
	}

	public void setNomeCasoTeste(String nomeCasoTeste) {
		this.nomeCasoTeste = nomeCasoTeste;
	}

	public Integer getCodSistema() {
		return codSistema;
	}

	public void setCodSistema(Integer codSistema) {
		this.codSistema = codSistema;
	}

	public Sistema getSistema() {
		return sistema;
	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}

}
