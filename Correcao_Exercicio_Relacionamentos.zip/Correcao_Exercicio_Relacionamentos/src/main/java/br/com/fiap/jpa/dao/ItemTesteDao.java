package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.ItemTeste;

public interface ItemTesteDao extends GenericDao<ItemTeste, Integer> {

}
