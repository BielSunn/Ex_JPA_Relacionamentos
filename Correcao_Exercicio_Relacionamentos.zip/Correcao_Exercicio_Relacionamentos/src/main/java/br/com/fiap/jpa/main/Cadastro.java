package br.com.fiap.jpa.main;

public class Cadastro {

//		Cadastrar com o cascade:
	public static void main(String[] args) {

//		Instanciar o caso teste com o sistema
		// CasoTeste casoTeste = new CasoTeste("Admiss�o" ,"Admiss�o de efetivo");

//		Instanciar o item teste com o caso teste e a lista de usuario
		// ItemTeste itensTeste = new ItemTeste("Admitir um colaborador com sucesso");

//		Adicionar o item no caso teste

	}

}
